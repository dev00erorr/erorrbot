const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType, ChannelType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');
const db = require('../../database/db');

module.exports = {
  category: 'settings',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  data: new SlashCommandBuilder()
    .setName('setlogs')
    .setDescription('تحديد قناة سجلات الإدارة (بدون قناة = تعطيل السجلات)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setContexts(InteractionContextType.Guild)
    .addChannelOption((o) =>
      o.setName('channel').setDescription('قناة السجلات')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    if (!channel) {
      db.setLogChannel(interaction.guildId, null);
      return interaction.reply({ embeds: [embeds.success('تم تعطيل إرسال السجلات.')] });
    }
    const me = await interaction.guild.members.fetchMe();
    const perms = channel.permissionsFor(me);
    if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
      return mod.fail(interaction, `لا يملك البوت صلاحيات (عرض القناة، إرسال الرسائل، تضمين الروابط) في ${channel}.`);
    }
    db.setLogChannel(interaction.guildId, channel.id);
    await channel.send({ embeds: [embeds.info('تم تعيين هذه القناة لسجلات الإدارة ✅', '📋 قناة السجلات')] }).catch(() => {});
    await interaction.reply({ embeds: [embeds.success(`ستُرسل سجلات الإدارة إلى ${channel}.`)] });
  },
};
