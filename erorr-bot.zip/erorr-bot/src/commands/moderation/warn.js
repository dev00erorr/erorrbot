const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');
const db = require('../../database/db');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('إرسال تحذير لعضو وتسجيله')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('سبب التحذير').setRequired(true).setMaxLength(400)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason', true);

    if (!member) return mod.fail(interaction, 'هذا المستخدم ليس عضوًا في السيرفر.');
    if (user.bot) return mod.fail(interaction, 'لا يمكن تحذير البوتات.');
    const problem = await mod.checkTarget(interaction, user, member);
    if (problem) return mod.fail(interaction, problem);

    await interaction.deferReply();
    const id = await mod.record(interaction, { type: 'warn', user, reason });
    const dmSent = await mod.dmUser(user, interaction.guild, 'warn', reason);
    const total = db.countWarnings(interaction.guildId, user.id);
    await interaction.editReply({
      embeds: [embeds.success(
        `تم تحذير ${user}\n**السبب:** ${reason}\n**عدد تحذيراته:** ${total}\n**رقم السجل:** #${id}${dmSent ? '' : '\n*(تعذر إرسال رسالة خاصة للعضو)*'}`,
        'تم التحذير',
      )],
    });
  },
};
