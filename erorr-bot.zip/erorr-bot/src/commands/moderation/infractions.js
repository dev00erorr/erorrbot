const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType, MessageFlags } = require('discord.js');
const embeds = require('../../utils/embeds');
const db = require('../../database/db');
const { TYPES } = require('../../utils/moderation');
const { discordTime, formatDuration } = require('../../utils/time');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  data: new SlashCommandBuilder()
    .setName('infractions')
    .setDescription('عرض سجل عقوبات وتحذيرات عضو')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const rows = db.listInfractions(interaction.guildId, user.id, 10);
    if (rows.length === 0) {
      return interaction.reply({ embeds: [embeds.info(`لا يوجد أي سجل عقوبات لـ ${user}.`, '📋 السجل')], flags: MessageFlags.Ephemeral });
    }
    const totals = db.countByType(interaction.guildId, user.id)
      .map((r) => `${TYPES[r.type]?.label ?? r.type}: ${r.count}`).join(' • ');
    const lines = rows.map((r) => {
      const reason = (r.reason ?? '—').replace(/\s+/g, ' ').slice(0, 120);
      const dur = r.duration_ms ? ` (${formatDuration(r.duration_ms)})` : '';
      return `**#${r.id}** • ${TYPES[r.type]?.label ?? r.type}${dur} • ${discordTime(r.created_at, 'd')} • <@${r.moderator_id}>\n> ${reason}`;
    });
    const embed = embeds
      .info(lines.join('\n'), `📋 سجل ${user.username}`)
      .addFields({ name: 'الإجمالي', value: totals })
      .setThumbnail(user.displayAvatarURL({ size: 128 }));
    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};
