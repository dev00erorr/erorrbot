const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.BanMembers],
  botPermissions: [PermissionFlagsBits.BanMembers],
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('حظر عضو من السيرفر')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو المراد حظره').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('سبب الحظر').setMaxLength(400))
    .addIntegerOption((o) =>
      o.setName('delete_days').setDescription('حذف رسائل العضو من آخر عدد أيام (0-7)').setMinValue(0).setMaxValue(7)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const member = interaction.options.getMember('user');
    const reason = mod.getReason(interaction);
    const days = interaction.options.getInteger('delete_days') ?? 0;

    const problem = await mod.checkTarget(interaction, user, member);
    if (problem) return mod.fail(interaction, problem);
    if (member && !member.bannable) return mod.fail(interaction, 'لا أستطيع حظر هذا العضو.');

    await interaction.deferReply();
    const dmSent = await mod.dmUser(user, interaction.guild, 'ban', reason);
    try {
      await interaction.guild.members.ban(user, {
        reason: mod.auditReason(interaction, reason),
        deleteMessageSeconds: days * 86_400,
      });
    } catch (error) {
      console.error('[ban]', error);
      return mod.fail(interaction, 'فشل تنفيذ الحظر. تأكد من صلاحيات البوت وترتيب رتبته.');
    }
    const id = await mod.record(interaction, { type: 'ban', user, reason });
    await interaction.editReply({
      embeds: [embeds.success(`تم حظر ${user} (\`${user.username}\`)\n**السبب:** ${reason}\n**رقم السجل:** #${id}${dmSent ? '' : '\n*(تعذر إرسال رسالة خاصة للعضو)*'}`, 'تم الحظر')],
    });
  },
};
