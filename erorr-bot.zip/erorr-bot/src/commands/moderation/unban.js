const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.BanMembers],
  botPermissions: [PermissionFlagsBits.BanMembers],
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('إلغاء حظر مستخدم عن طريق معرّفه')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setContexts(InteractionContextType.Guild)
    .addStringOption((o) => o.setName('user_id').setDescription('معرّف المستخدم المحظور').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('سبب إلغاء الحظر').setMaxLength(400)),
  async execute(interaction) {
    const id = interaction.options.getString('user_id', true).trim();
    const reason = mod.getReason(interaction);
    if (!/^\d{17,20}$/.test(id)) return mod.fail(interaction, 'المعرّف غير صالح. المعرّف أرقام فقط (17-20 رقمًا).');

    await interaction.deferReply();
    const ban = await interaction.guild.bans.fetch(id).catch(() => null);
    if (!ban) return mod.fail(interaction, 'هذا المعرّف غير محظور في السيرفر.');

    try {
      await interaction.guild.members.unban(id, mod.auditReason(interaction, reason));
    } catch (error) {
      console.error('[unban]', error);
      return mod.fail(interaction, 'فشل إلغاء الحظر. تأكد من صلاحيات البوت.');
    }
    const logId = await mod.record(interaction, { type: 'unban', user: ban.user, reason });
    await interaction.editReply({
      embeds: [embeds.success(`تم إلغاء حظر ${ban.user} (\`${ban.user.username}\`)\n**رقم السجل:** #${logId}`, 'تم إلغاء الحظر')],
    });
  },
};
