const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');
const { toMs, formatDuration, discordTime, MAX_TIMEOUT_MS } = require('../../utils/time');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  botPermissions: [PermissionFlagsBits.ModerateMembers],
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('إعطاء عضو تايم أوت (كتم مؤقت)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو').setRequired(true))
    .addIntegerOption((o) => o.setName('amount').setDescription('عدد وحدات المدة').setRequired(true).setMinValue(1))
    .addStringOption((o) =>
      o.setName('unit').setDescription('وحدة المدة').setRequired(true).addChoices(
        { name: 'دقائق', value: 'minutes' },
        { name: 'ساعات', value: 'hours' },
        { name: 'أيام', value: 'days' },
      ))
    .addStringOption((o) => o.setName('reason').setDescription('سبب التايم أوت').setMaxLength(400)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const member = interaction.options.getMember('user');
    const reason = mod.getReason(interaction);
    const ms = toMs(interaction.options.getInteger('amount', true), interaction.options.getString('unit', true));

    if (ms > MAX_TIMEOUT_MS) return mod.fail(interaction, 'أقصى مدة للتايم أوت في Discord هي 28 يومًا.');
    if (!member) return mod.fail(interaction, 'هذا المستخدم ليس عضوًا في السيرفر.');
    const problem = await mod.checkTarget(interaction, user, member);
    if (problem) return mod.fail(interaction, problem);
    if (!member.moderatable) return mod.fail(interaction, 'لا أستطيع إعطاء هذا العضو تايم أوت (قد يكون لديه صلاحية Administrator).');

    await interaction.deferReply();
    try {
      await member.timeout(ms, mod.auditReason(interaction, reason));
    } catch (error) {
      console.error('[timeout]', error);
      return mod.fail(interaction, 'فشل تنفيذ التايم أوت. تأكد من صلاحيات البوت وترتيب رتبته.');
    }
    const dmSent = await mod.dmUser(user, interaction.guild, 'timeout', reason, ms);
    const id = await mod.record(interaction, { type: 'timeout', user, reason, durationMs: ms });
    await interaction.editReply({
      embeds: [embeds.success(
        `تم إعطاء ${user} تايم أوت لمدة **${formatDuration(ms)}** (ينتهي ${discordTime(Date.now() + ms, 'R')})\n**السبب:** ${reason}\n**رقم السجل:** #${id}${dmSent ? '' : '\n*(تعذر إرسال رسالة خاصة للعضو)*'}`,
        'تم التايم أوت',
      )],
    });
  },
};
