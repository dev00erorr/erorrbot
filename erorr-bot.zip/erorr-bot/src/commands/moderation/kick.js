const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.KickMembers],
  botPermissions: [PermissionFlagsBits.KickMembers],
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('طرد عضو من السيرفر')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو المراد طرده').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('سبب الطرد').setMaxLength(400)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const member = interaction.options.getMember('user');
    const reason = mod.getReason(interaction);

    if (!member) return mod.fail(interaction, 'هذا المستخدم ليس عضوًا في السيرفر.');
    const problem = await mod.checkTarget(interaction, user, member);
    if (problem) return mod.fail(interaction, problem);
    if (!member.kickable) return mod.fail(interaction, 'لا أستطيع طرد هذا العضو.');

    await interaction.deferReply();
    const dmSent = await mod.dmUser(user, interaction.guild, 'kick', reason);
    try {
      await member.kick(mod.auditReason(interaction, reason));
    } catch (error) {
      console.error('[kick]', error);
      return mod.fail(interaction, 'فشل تنفيذ الطرد. تأكد من صلاحيات البوت وترتيب رتبته.');
    }
    const id = await mod.record(interaction, { type: 'kick', user, reason });
    await interaction.editReply({
      embeds: [embeds.success(`تم طرد ${user} (\`${user.username}\`)\n**السبب:** ${reason}\n**رقم السجل:** #${id}${dmSent ? '' : '\n*(تعذر إرسال رسالة خاصة للعضو)*'}`, 'تم الطرد')],
    });
  },
};
