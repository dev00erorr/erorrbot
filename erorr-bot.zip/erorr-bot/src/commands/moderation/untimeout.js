const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  botPermissions: [PermissionFlagsBits.ModerateMembers],
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('إزالة التايم أوت عن عضو')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('السبب').setMaxLength(400)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const member = interaction.options.getMember('user');
    const reason = mod.getReason(interaction);

    if (!member) return mod.fail(interaction, 'هذا المستخدم ليس عضوًا في السيرفر.');
    if (!member.isCommunicationDisabled()) return mod.fail(interaction, 'هذا العضو ليس تحت تايم أوت.');
    const problem = await mod.checkTarget(interaction, user, member);
    if (problem) return mod.fail(interaction, problem);

    await interaction.deferReply();
    try {
      await member.timeout(null, mod.auditReason(interaction, reason));
    } catch (error) {
      console.error('[untimeout]', error);
      return mod.fail(interaction, 'فشلت إزالة التايم أوت. تأكد من صلاحيات البوت وترتيب رتبته.');
    }
    const id = await mod.record(interaction, { type: 'untimeout', user, reason });
    await interaction.editReply({
      embeds: [embeds.success(`تمت إزالة التايم أوت عن ${user}\n**رقم السجل:** #${id}`, 'تمت الإزالة')],
    });
  },
};
