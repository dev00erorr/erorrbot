const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType, MessageFlags } = require('discord.js');
const embeds = require('../../utils/embeds');
const mod = require('../../utils/moderation');
const { logAction } = require('../../utils/logger');
const { colors } = require('../../config');

module.exports = {
  category: 'moderation',
  userPermissions: [PermissionFlagsBits.ManageMessages],
  botPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ReadMessageHistory],
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('مسح عدد من الرسائل في القناة الحالية')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setContexts(InteractionContextType.Guild)
    .addIntegerOption((o) => o.setName('amount').setDescription('عدد الرسائل (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption((o) => o.setName('user').setDescription('مسح رسائل عضو معيّن فقط')),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount', true);
    const target = interaction.options.getUser('user');
    const channel = interaction.channel;
    if (!channel || typeof channel.bulkDelete !== 'function') {
      return mod.fail(interaction, 'لا يمكن مسح الرسائل في هذه القناة.');
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const fetched = await channel.messages.fetch({ limit: 100 });
    const toDelete = fetched
      .filter((m) => !m.pinned && (!target || m.author.id === target.id))
      .first(amount);
    // true = تجاهل الرسائل الأقدم من 14 يومًا (قيد Discord الرسمي)
    const deleted = toDelete.length ? await channel.bulkDelete(toDelete, true) : { size: 0 };

    if (deleted.size === 0) {
      return interaction.editReply({ embeds: [embeds.warning('لم يتم حذف أي رسالة. الرسائل الأقدم من 14 يومًا أو المثبّتة لا يمكن مسحها بهذه الطريقة.')] });
    }
    await logAction(interaction.guild, {
      title: '🧹 مسح رسائل',
      color: colors.warn,
      fields: [
        { name: 'المشرف', value: `${interaction.user}`, inline: true },
        { name: 'القناة', value: `${channel}`, inline: true },
        { name: 'العدد', value: `${deleted.size}`, inline: true },
        ...(target ? [{ name: 'رسائل العضو', value: `${target}`, inline: true }] : []),
      ],
    });
    await interaction.editReply({ embeds: [embeds.success(`تم حذف **${deleted.size}** رسالة.`)] });
  },
};
