const { SlashCommandBuilder, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');

module.exports = {
  category: 'general',
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('عرض صورة عضو')
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو (الافتراضي: أنت)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    const link = (ext) => user.displayAvatarURL({ extension: ext, size: 1024 });
    const links = [`[PNG](${link('png')})`, `[JPG](${link('jpg')})`, `[WEBP](${link('webp')})`];
    if (user.avatar?.startsWith('a_')) links.push(`[GIF](${link('gif')})`);
    const embed = embeds
      .info(links.join(' • '), `🖼️ صورة ${user.username}`)
      .setImage(user.displayAvatarURL({ size: 1024 }));
    await interaction.reply({ embeds: [embed] });
  },
};
