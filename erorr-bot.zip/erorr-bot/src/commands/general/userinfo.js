const { SlashCommandBuilder, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const { discordTime } = require('../../utils/time');

module.exports = {
  category: 'general',
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('عرض معلومات عضو')
    .setContexts(InteractionContextType.Guild)
    .addUserOption((o) => o.setName('user').setDescription('العضو (الافتراضي: أنت)')),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const user = target ?? interaction.user;
    const member = target ? interaction.options.getMember('user') : interaction.member;

    const embed = embeds
      .info(`${user}`, `👤 ${user.username}`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: 'المعرّف', value: `\`${user.id}\``, inline: true },
        { name: 'بوت؟', value: user.bot ? 'نعم' : 'لا', inline: true },
        { name: 'إنشاء الحساب', value: discordTime(user.createdTimestamp) },
      );

    if (member) {
      const roles = member.roles.cache
        .filter((r) => r.id !== interaction.guildId)
        .sort((a, b) => b.position - a.position)
        .first(15)
        .map((r) => r.toString());
      embed.addFields(
        { name: 'الانضمام للسيرفر', value: member.joinedTimestamp ? discordTime(member.joinedTimestamp) : 'غير معروف' },
        { name: 'أعلى رول', value: member.roles.highest.id === interaction.guildId ? 'لا يوجد' : `${member.roles.highest}`, inline: true },
        { name: 'تايم أوت', value: member.isCommunicationDisabled() ? `حتى ${discordTime(member.communicationDisabledUntilTimestamp, 'R')}` : 'لا', inline: true },
        { name: `الرولات (${roles.length})`, value: roles.join(' ') || 'لا يوجد' },
      );
    } else {
      embed.addFields({ name: 'الحالة', value: 'هذا المستخدم ليس عضوًا في السيرفر.' });
    }
    await interaction.reply({ embeds: [embed] });
  },
};
