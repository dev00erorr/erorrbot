const { SlashCommandBuilder, InteractionContextType } = require('discord.js');
const embeds = require('../../utils/embeds');
const { discordTime } = require('../../utils/time');

const VERIFICATION = ['لا يوجد', 'منخفض', 'متوسط', 'عالٍ', 'الأعلى'];

module.exports = {
  category: 'general',
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('عرض معلومات السيرفر')
    .setContexts(InteractionContextType.Guild),
  async execute(interaction) {
    const { guild } = interaction;
    const embed = embeds
      .info(guild.description ?? '', `🏰 ${guild.name}`)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .addFields(
        { name: 'المالك', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'المعرّف', value: `\`${guild.id}\``, inline: true },
        { name: 'تاريخ الإنشاء', value: discordTime(guild.createdTimestamp), inline: false },
        { name: 'الأعضاء', value: `${guild.memberCount}`, inline: true },
        { name: 'القنوات', value: `${guild.channels.cache.size}`, inline: true },
        { name: 'الرولات', value: `${guild.roles.cache.size}`, inline: true },
        { name: 'البوستات', value: `${guild.premiumSubscriptionCount ?? 0} (المستوى ${guild.premiumTier})`, inline: true },
        { name: 'مستوى التحقق', value: VERIFICATION[guild.verificationLevel] ?? 'غير معروف', inline: true },
      );
    await interaction.reply({ embeds: [embed] });
  },
};
