const {
  SlashCommandBuilder, InteractionContextType, EmbedBuilder, ActionRowBuilder,
  StringSelectMenuBuilder, ComponentType, MessageFlags,
} = require('discord.js');
const { colors, botName } = require('../../config');

const CATEGORIES = {
  general: { label: 'عام', emoji: '🌐', description: 'معلومات وأدوات عامة' },
  moderation: { label: 'الإشراف', emoji: '🛡️', description: 'العقوبات وإدارة الرسائل' },
  settings: { label: 'الإعدادات', emoji: '⚙️', description: 'إعدادات البوت في السيرفر' },
};

const commandsOf = (client, key) => [...client.commands.values()].filter((c) => c.category === key);

function homeEmbed(client) {
  const lines = Object.entries(CATEGORIES)
    .map(([key, c]) => ({ c, n: commandsOf(client, key).length }))
    .filter(({ n }) => n > 0)
    .map(({ c, n }) => `${c.emoji} **${c.label}** — ${c.description} (${n})`);
  return new EmbedBuilder()
    .setColor(colors.info)
    .setTitle(`📖 قائمة أوامر ${botName}`)
    .setDescription(`اختر قسمًا من القائمة بالأسفل لعرض أوامره.\n\n${lines.join('\n')}`)
    .setFooter({ text: botName });
}

function categoryEmbed(client, key) {
  const c = CATEGORIES[key];
  const lines = commandsOf(client, key).map((cmd) => `\`/${cmd.data.name}\` — ${cmd.data.description}`);
  return new EmbedBuilder()
    .setColor(colors.info)
    .setTitle(`${c.emoji} ${c.label}`)
    .setDescription(lines.join('\n') || 'لا توجد أوامر في هذا القسم.')
    .setFooter({ text: botName });
}

function menu(client, selected) {
  const options = [{ label: 'الرئيسية', value: 'home', emoji: '📖', default: selected === 'home' }];
  for (const [key, c] of Object.entries(CATEGORIES)) {
    if (commandsOf(client, key).length === 0) continue;
    options.push({ label: c.label, value: key, emoji: c.emoji, description: c.description, default: selected === key });
  }
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder().setCustomId('help:category').setPlaceholder('اختر قسمًا').addOptions(options),
  );
}

module.exports = {
  category: 'general',
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('عرض قائمة أوامر البوت')
    .setContexts(InteractionContextType.Guild),
  async execute(interaction) {
    const { client } = interaction;
    await interaction.reply({ embeds: [homeEmbed(client)], components: [menu(client, 'home')] });
    const message = await interaction.fetchReply();

    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 120_000,
    });
    collector.on('collect', async (i) => {
      if (i.user.id !== interaction.user.id) {
        return i.reply({ content: 'هذه القائمة خاصة بمن استدعى الأمر. استخدم /help لفتح قائمتك.', flags: MessageFlags.Ephemeral });
      }
      const key = i.values[0];
      const embed = key === 'home' ? homeEmbed(client) : categoryEmbed(client, key);
      await i.update({ embeds: [embed], components: [menu(client, key)] });
    });
    collector.on('end', () => interaction.editReply({ components: [] }).catch(() => {}));
  },
};
