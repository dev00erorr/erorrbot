const UNITS = { minutes: 60_000, hours: 3_600_000, days: 86_400_000 };
const MAX_TIMEOUT_MS = 28 * UNITS.days; // الحد الأقصى الذي تسمح به Discord

function toMs(amount, unit) {
  const factor = UNITS[unit];
  if (!factor || !Number.isFinite(amount) || amount <= 0) {
    throw new RangeError('مدة غير صالحة');
  }
  return amount * factor;
}

function formatDuration(ms) {
  const days = Math.floor(ms / UNITS.days);
  const hours = Math.floor((ms % UNITS.days) / UNITS.hours);
  const minutes = Math.floor((ms % UNITS.hours) / UNITS.minutes);
  const parts = [];
  if (days) parts.push(`${days} يوم`);
  if (hours) parts.push(`${hours} ساعة`);
  if (minutes) parts.push(`${minutes} دقيقة`);
  return parts.length ? parts.join(' و ') : 'أقل من دقيقة';
}

// style: F = تاريخ كامل، R = نسبي (قبل/بعد)، d = تاريخ قصير
function discordTime(ms, style = 'F') {
  return `<t:${Math.floor(ms / 1000)}:${style}>`;
}

module.exports = { UNITS, MAX_TIMEOUT_MS, toMs, formatDuration, discordTime };
