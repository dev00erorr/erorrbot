const { EmbedBuilder } = require('discord.js');
const db = require('../database/db');
const { colors, botName } = require('../config');

// يرسل سجلًا إلى قناة Logs الخاصة بالسيرفر إن كانت معرّفة. لا يرمي أخطاء أبدًا.
async function logAction(guild, { title, color = colors.info, description, fields = [] }) {
  try {
    const { log_channel_id: channelId } = db.getSettings(guild.id);
    if (!channelId) return false;
    const channel = await guild.channels.fetch(channelId).catch(() => null);
    if (!channel || !channel.isTextBased()) return false;

    const embed = new EmbedBuilder().setColor(color).setTitle(title).setFooter({ text: botName }).setTimestamp();
    if (description) embed.setDescription(description);
    if (fields.length) embed.addFields(fields);
    await channel.send({ embeds: [embed] });
    return true;
  } catch (error) {
    console.error('[سجل] فشل إرسال السجل:', error.message);
    return false;
  }
}

module.exports = { logAction };
