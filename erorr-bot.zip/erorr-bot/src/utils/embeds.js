const { EmbedBuilder } = require('discord.js');
const { colors, botName } = require('../config');

const base = (color) => new EmbedBuilder().setColor(color).setFooter({ text: botName }).setTimestamp();

module.exports = {
  base,
  success: (description, title = 'تم بنجاح') => base(colors.success).setTitle(`✅ ${title}`).setDescription(description),
  error: (description, title = 'تعذر التنفيذ') => base(colors.error).setTitle(`❌ ${title}`).setDescription(description),
  warning: (description, title = 'تنبيه') => base(colors.warn).setTitle(`⚠️ ${title}`).setDescription(description),
  info: (description, title) => {
    const e = base(colors.info).setDescription(description);
    return title ? e.setTitle(title) : e;
  },
};
