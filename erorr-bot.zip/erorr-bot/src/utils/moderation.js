const { MessageFlags } = require('discord.js');
const db = require('../database/db');
const embeds = require('./embeds');
const { logAction } = require('./logger');
const { colors } = require('../config');
const { formatDuration } = require('./time');

const TYPES = {
  ban: { label: 'حظر', color: colors.error },
  unban: { label: 'إلغاء حظر', color: colors.success },
  kick: { label: 'طرد', color: colors.warn },
  timeout: { label: 'تايم أوت', color: colors.warn },
  untimeout: { label: 'إلغاء تايم أوت', color: colors.success },
  warn: { label: 'تحذير', color: colors.warn },
};

const DEFAULT_REASON = 'لم يتم تحديد سبب';

const getReason = (interaction) => interaction.options.getString('reason') ?? DEFAULT_REASON;
const auditReason = (interaction, reason) =>
  `${interaction.user.username} (${interaction.user.id}) | ${reason}`.slice(0, 512);

// رد خطأ مناسب سواء تم تأجيل الرد أم لا
function fail(interaction, text) {
  const payload = { embeds: [embeds.error(text)] };
  if (interaction.deferred) return interaction.editReply(payload);
  return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
}

// التحقق من الهرمية: المشرف والبوت يجب أن تكون رتبتهما أعلى من رتبة الهدف
async function checkTarget(interaction, user, member) {
  const { guild } = interaction;
  if (user.id === interaction.user.id) return 'لا يمكنك تنفيذ هذا الإجراء على نفسك.';
  if (user.id === interaction.client.user.id) return 'لا يمكنك تنفيذ هذا الإجراء على البوت.';
  if (user.id === guild.ownerId) return 'لا يمكن تنفيذ هذا الإجراء على مالك السيرفر.';
  if (!member) return null; // العضو خارج السيرفر (مثلًا عند الحظر)

  const issuerIsOwner = interaction.user.id === guild.ownerId;
  if (!issuerIsOwner && interaction.member.roles.highest.comparePositionTo(member.roles.highest) <= 0) {
    return 'رتبة هذا العضو مساوية لرتبتك أو أعلى منها.';
  }
  const me = await guild.members.fetchMe();
  if (me.roles.highest.comparePositionTo(member.roles.highest) <= 0) {
    return 'رتبة البوت ليست أعلى من رتبة هذا العضو. ارفع رتبة البوت من إعدادات السيرفر.';
  }
  return null;
}

async function dmUser(user, guild, type, reason, durationMs = null) {
  const embed = embeds
    .warning(`تم تنفيذ إجراء **${TYPES[type].label}** بحقك في سيرفر **${guild.name}**.`)
    .addFields({ name: 'السبب', value: reason.slice(0, 1000) });
  if (durationMs) embed.addFields({ name: 'المدة', value: formatDuration(durationMs) });
  try {
    await user.send({ embeds: [embed] });
    return true;
  } catch {
    return false; // الخاص مغلق
  }
}

// يحفظ العقوبة في قاعدة البيانات ويرسلها إلى قناة Logs
async function record(interaction, { type, user, reason, durationMs = null }) {
  const id = db.addInfraction({
    guildId: interaction.guildId,
    userId: user.id,
    moderatorId: interaction.user.id,
    type,
    reason,
    durationMs,
  });
  const fields = [
    { name: 'العضو', value: `${user} (\`${user.id}\`)`, inline: true },
    { name: 'المشرف', value: `${interaction.user}`, inline: true },
    { name: 'السبب', value: reason.slice(0, 1000) },
  ];
  if (durationMs) fields.push({ name: 'المدة', value: formatDuration(durationMs), inline: true });
  await logAction(interaction.guild, {
    title: `📋 ${TYPES[type].label} | #${id}`,
    color: TYPES[type].color,
    fields,
  });
  return id;
}

module.exports = { TYPES, getReason, auditReason, fail, checkTarget, dmUser, record };
