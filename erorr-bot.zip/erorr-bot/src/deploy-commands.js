const { REST, Routes } = require('discord.js');
const config = require('./config');
config.assertEnv();
const { loadCommands } = require('./handlers/commands');

(async () => {
  const body = [...loadCommands().values()].map((c) => c.data.toJSON());
  const rest = new REST({ version: '10' }).setToken(config.token);
  const route = config.guildId
    ? Routes.applicationGuildCommands(config.clientId, config.guildId)
    : Routes.applicationCommands(config.clientId);
  const data = await rest.put(route, { body });
  console.log(`[نشر] تم تسجيل ${data.length} أمر ${config.guildId ? `في السيرفر ${config.guildId}` : 'بشكل عام (قد يتأخر ظهورها قليلًا)'}`);
})().catch((e) => {
  console.error('[نشر] فشل تسجيل الأوامر:', e);
  process.exit(1);
});
