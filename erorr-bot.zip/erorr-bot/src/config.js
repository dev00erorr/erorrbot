require('dotenv').config();

const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID || null,
  dbPath: process.env.DATABASE_PATH || './data/erorr.sqlite',
  botName: 'ERORR BOT',
  colors: { success: 0x2ecc71, error: 0xe74c3c, warn: 0xf1c40f, info: 0x5865f2 },
};

function assertEnv() {
  const missing = ['DISCORD_TOKEN', 'CLIENT_ID'].filter((k) => !process.env[k]);
  if (missing.length) {
    console.error(`[إعدادات] متغيرات مفقودة في ملف .env: ${missing.join(', ')}`);
    process.exit(1);
  }
}

module.exports = { ...config, assertEnv };
