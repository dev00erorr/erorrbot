const { Events, MessageFlags, PermissionsBitField } = require('discord.js');
const embeds = require('../utils/embeds');

const names = (perms) => new PermissionsBitField(perms).toArray().join(', ');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;
    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) return;

    const deny = (text) =>
      interaction.reply({ embeds: [embeds.error(text)], flags: MessageFlags.Ephemeral });

    if (!interaction.inGuild()) return deny('هذا الأمر يعمل داخل السيرفرات فقط.');

    // لا نعتمد على إعدادات Discord وحدها: نتحقق من الصلاحيات داخل الكود أيضًا
    if (command.userPermissions?.length && !interaction.memberPermissions?.has(command.userPermissions)) {
      return deny(`ليست لديك الصلاحية اللازمة: \`${names(command.userPermissions)}\``);
    }
    if (command.botPermissions?.length && !interaction.appPermissions?.has(command.botPermissions)) {
      return deny(`ينقص البوت صلاحيات في هذه القناة: \`${names(command.botPermissions)}\``);
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      console.error(`[خطأ] /${interaction.commandName}:`, error);
      const payload = {
        embeds: [embeds.error('حدث خطأ غير متوقع أثناء تنفيذ الأمر. حاول مرة أخرى لاحقًا.')],
        flags: MessageFlags.Ephemeral,
      };
      if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => {});
      else await interaction.reply(payload).catch(() => {});
    }
  },
};
