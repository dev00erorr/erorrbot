const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`[جاهز] ${client.user.tag} | عدد السيرفرات: ${client.guilds.cache.size}`);
    client.user.setPresence({
      activities: [{ name: '/help | ERORR BOT', type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
