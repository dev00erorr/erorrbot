const { Client, GatewayIntentBits, Events } = require('discord.js');
const config = require('./config');
config.assertEnv();

const db = require('./database/db');
const { loadCommands } = require('./handlers/commands');
const { loadEvents } = require('./handlers/events');

// أقل قدر من الـ Intents: Guilds فقط (لا يحتاج أي Privileged Intent)
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.commands = loadCommands();
loadEvents(client);

client.on(Events.Error, (e) => console.error('[عميل] خطأ:', e));
client.on(Events.Warn, (m) => console.warn('[عميل] تحذير:', m));
client.on(Events.ShardDisconnect, (ev, id) => console.warn(`[اتصال] انقطع الشارد ${id} (الكود ${ev.code})`));
client.on(Events.ShardReconnecting, (id) => console.log(`[اتصال] إعادة اتصال الشارد ${id}...`));
client.on(Events.ShardResume, (id) => console.log(`[اتصال] استأنف الشارد ${id}`));

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e));

function shutdown() {
  console.log('[إيقاف] جاري إغلاق البوت...');
  client.destroy();
  db.close();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

client.login(config.token);
