const fs = require('node:fs');
const path = require('node:path');
const { Collection } = require('discord.js');

// يقرأ كل ملفات الأوامر من src/commands/<قسم>/<أمر>.js
function loadCommands() {
  const commands = new Collection();
  const root = path.join(__dirname, '..', 'commands');
  for (const folder of fs.readdirSync(root, { withFileTypes: true })) {
    if (!folder.isDirectory()) continue;
    const files = fs.readdirSync(path.join(root, folder.name)).filter((f) => f.endsWith('.js'));
    for (const file of files) {
      const command = require(path.join(root, folder.name, file));
      if (!command.data || typeof command.execute !== 'function') {
        console.warn(`[أوامر] تم تجاهل ${folder.name}/${file}: ينقصه data أو execute`);
        continue;
      }
      command.category ??= folder.name;
      if (commands.has(command.data.name)) throw new Error(`اسم أمر مكرر: ${command.data.name}`);
      commands.set(command.data.name, command);
    }
  }
  return commands;
}

module.exports = { loadCommands };
