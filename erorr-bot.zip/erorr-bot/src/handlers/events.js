const fs = require('node:fs');
const path = require('node:path');

function loadEvents(client) {
  const dir = path.join(__dirname, '..', 'events');
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.js'))) {
    const event = require(path.join(dir, file));
    const run = (...args) =>
      Promise.resolve(event.execute(...args)).catch((e) => console.error(`[حدث] خطأ في ${event.name}:`, e));
    if (event.once) client.once(event.name, run);
    else client.on(event.name, run);
  }
}

module.exports = { loadEvents };
