const test = require('node:test');
const assert = require('node:assert/strict');
const { toMs, formatDuration, MAX_TIMEOUT_MS } = require('../src/utils/time');

test('toMs يحوّل الوحدات بشكل صحيح', () => {
  assert.equal(toMs(5, 'minutes'), 300_000);
  assert.equal(toMs(2, 'hours'), 7_200_000);
  assert.equal(toMs(1, 'days'), 86_400_000);
});

test('toMs يرفض القيم غير الصالحة', () => {
  assert.throws(() => toMs(0, 'minutes'), RangeError);
  assert.throws(() => toMs(-1, 'hours'), RangeError);
  assert.throws(() => toMs(1, 'weeks'), RangeError);
  assert.throws(() => toMs(NaN, 'days'), RangeError);
});

test('formatDuration ينسّق المدة بالعربية', () => {
  assert.equal(formatDuration(90 * 60_000), '1 ساعة و 30 دقيقة');
  assert.equal(formatDuration(86_400_000), '1 يوم');
  assert.equal(formatDuration(10_000), 'أقل من دقيقة');
});

test('الحد الأقصى للتايم أوت 28 يومًا', () => {
  assert.equal(MAX_TIMEOUT_MS, 28 * 86_400_000);
  assert.ok(toMs(29, 'days') > MAX_TIMEOUT_MS);
});
