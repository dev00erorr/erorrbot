const test = require('node:test');
const assert = require('node:assert/strict');

let available = true;
try {
  require.resolve('better-sqlite3');
  require.resolve('dotenv');
} catch {
  available = false;
}

test('قاعدة البيانات: الإعدادات وسجل العقوبات', { skip: !available && 'better-sqlite3 غير مثبتة' }, () => {
  process.env.DATABASE_PATH = ':memory:';
  const db = require('../src/database/db');

  assert.equal(db.getSettings('g1').log_channel_id, null);
  db.setLogChannel('g1', 'c1');
  assert.equal(db.getSettings('g1').log_channel_id, 'c1');
  db.setLogChannel('g1', null);
  assert.equal(db.getSettings('g1').log_channel_id, null);

  const base = { guildId: 'g1', userId: 'u1', moderatorId: 'm1' };
  const a = db.addInfraction({ ...base, type: 'warn', reason: 'سبب 1' });
  const b = db.addInfraction({ ...base, type: 'timeout', reason: 'سبب 2', durationMs: 60_000 });
  db.addInfraction({ ...base, guildId: 'g2', type: 'warn', reason: 'سيرفر آخر' });

  assert.ok(b > a);
  const rows = db.listInfractions('g1', 'u1');
  assert.equal(rows.length, 2);
  assert.equal(rows[0].id, b); // الأحدث أولًا
  assert.equal(db.countWarnings('g1', 'u1'), 1); // لا اختلاط بين السيرفرات
  db.close();
});
