# ERORR BOT 🤖

بوت ديسكورد لإدارة السيرفرات، مبني بـ **Node.js + Discord.js v14 + SQLite**، بواجهة عربية.

> **حالة المشروع: المرحلة 1 من 8** — راجع جدول المراحل في الأسفل لمعرفة ما هو مُنفّذ فعلًا وما هو متبقٍ.

## المتطلبات
- Node.js **20 LTS** أو أحدث (الحد الأدنى 18.17)
- حساب Discord وصلاحية إنشاء تطبيق في Developer Portal

## 1) إنشاء التطبيق والبوت
1. افتح <https://discord.com/developers/applications> ثم **New Application** واختر الاسم `ERORR BOT`.
2. من **General Information** انسخ **Application ID** (هذا هو `CLIENT_ID`).
3. من قسم **Bot** اضغط **Reset Token** وانسخ التوكن (هذا هو `DISCORD_TOKEN`). **لا تشاركه ولا ترفعه على GitHub.**
4. **Privileged Intents:** المرحلة الحالية **لا تحتاج أي Intent مميّز**، اترك الثلاثة مغلقة.
   (ستُطلب لاحقًا: `Server Members Intent` للترحيب والرولات التلقائية، و`Message Content Intent` للحذف التلقائي للروابط.)

## 2) إضافة البوت إلى السيرفر بأقل صلاحيات
استبدل `YOUR_CLIENT_ID` ثم افتح الرابط:

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot%20applications.commands&permissions=1099511720966
```

الصلاحيات الممنوحة: View Channels، Send Messages، Embed Links، Read Message History، Manage Messages، Kick Members، Ban Members، Moderate Members.

> **مهم:** ارفع رتبة البوت في إعدادات السيرفر → الرولات فوق رتب الأعضاء الذين تريد أن يتحكم بهم.

## 3) التثبيت والإعداد
```bash
npm install
cp .env.example .env     # ثم املأ DISCORD_TOKEN و CLIENT_ID
```
للتجربة السريعة ضع `GUILD_ID` (معرّف سيرفرك) في `.env` فتظهر الأوامر فورًا. بدونه تُسجَّل الأوامر عامة وقد يتأخر ظهورها.

> لتفعيل وضع المطور في Discord لنسخ المعرّفات: الإعدادات → المتقدم → Developer Mode.

قاعدة البيانات SQLite تُنشأ تلقائيًا في `./data/erorr.sqlite` عند أول تشغيل.

## 4) التشغيل
```bash
npm run deploy    # تسجيل أوامر السلاش (مرة، وعند إضافة أو تعديل أمر)
npm start         # تشغيل البوت
npm test          # الاختبارات
```

## الأوامر الحالية
| الأمر | الوصف | الصلاحية |
|---|---|---|
| `/help` | قائمة تفاعلية بالأوامر مقسّمة حسب الأقسام | الجميع |
| `/serverinfo` | معلومات السيرفر | الجميع |
| `/userinfo [user]` | معلومات عضو | الجميع |
| `/avatar [user]` | صورة عضو | الجميع |
| `/ban user [reason] [delete_days]` | حظر عضو (ويمكن حظر من خارج السيرفر) | Ban Members |
| `/unban user_id [reason]` | إلغاء حظر بالمعرّف | Ban Members |
| `/kick user [reason]` | طرد عضو | Kick Members |
| `/timeout user amount unit [reason]` | تايم أوت بالدقائق/الساعات/الأيام (حتى 28 يومًا) | Moderate Members |
| `/untimeout user [reason]` | إزالة التايم أوت | Moderate Members |
| `/warn user reason` | تحذير عضو وتسجيله | Moderate Members |
| `/infractions user` | سجل عقوبات عضو (آخر 10) | Moderate Members |
| `/clear amount [user]` | مسح 1-100 رسالة (الأحدث من 14 يومًا فقط، وتتجاهل المثبّتة) | Manage Messages |
| `/setlogs [channel]` | تحديد قناة السجلات (بدون قناة = تعطيل) | Manage Server |

كل أوامر العقوبات تتحقق من: صلاحية المشرف، صلاحية البوت، وهرمية الرتب (لا يمكن معاقبة من رتبته مساوية أو أعلى منك أو من البوت، ولا المالك).

## هيكل المشروع
```
erorr-bot/
├── package.json
├── .env.example
├── README.md
├── src/
│   ├── index.js              # نقطة التشغيل
│   ├── deploy-commands.js    # تسجيل أوامر السلاش
│   ├── config.js
│   ├── database/db.js        # SQLite (إعدادات كل سيرفر + سجل العقوبات)
│   ├── handlers/             # تحميل الأوامر والأحداث تلقائيًا
│   ├── events/               # ready, interactionCreate
│   ├── utils/                # embeds, logger, moderation, time
│   └── commands/
│       ├── general/          # help, serverinfo, userinfo, avatar
│       ├── moderation/       # ban, unban, kick, timeout, untimeout, warn, infractions, clear
│       └── settings/         # setlogs
└── test/
```
لإضافة أمر جديد: أنشئ ملفًا في مجلد القسم يصدّر `{ data, execute }` (وحقول اختيارية `userPermissions` و`botPermissions`) وسيُحمَّل تلقائيًا.

## جدول المراحل
| # | المرحلة | الحالة |
|---|---|---|
| 1 | الأساس + الإشراف الأساسي + `/help` + أوامر المعلومات + Logs | ✅ مكتوبة |
| 2 | نظام العقوبات التدريجي حسب عدد التحذيرات | ⏳ لم تبدأ |
| 3 | الرسائل: Embed/إعلان/ترحيب ومغادرة/Buttons وSelect Menus | ⏳ لم تبدأ |
| 4 | الرولات: إنشاء/تعديل/حذف، Auto Role، رولات بالأزرار، Reaction Roles | ⏳ لم تبدأ |
| 5 | Auto Moderation: روابط، سبام، كلمات ممنوعة، حذف تلقائي | ⏳ لم تبدأ |
| 6 | المهام المجدولة والتذكيرات | ⏳ لم تبدأ |
| 7 | أنظمة إضافية: poll, giveaway, suggest, report, lock, slowmode, afk | ⏳ لم تبدأ |
| 8 | الموسيقى + لوحة التحكم (Express + OAuth2) | ⏳ لم تبدأ |

## الأمان
- التوكن في `.env` فقط، والملف مستثنى في `.gitignore`.
- يستخدم البوت Intent واحدًا فقط حاليًا: `Guilds`.
- الأوامر الإدارية محصورة بالسيرفرات وتتحقق من الصلاحيات داخل الكود لا من إعدادات Discord وحدها.
